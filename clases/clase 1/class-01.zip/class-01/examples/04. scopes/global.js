let counter = 0;

function returnCount() {
  return counter;
}

console.log(returnCount());
