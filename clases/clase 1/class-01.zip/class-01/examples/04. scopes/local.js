let state;

function setState() {
  let state = "on";
}

setState();

console.log(state); // Undefined
