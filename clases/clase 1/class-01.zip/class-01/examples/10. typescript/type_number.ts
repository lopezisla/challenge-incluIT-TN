let myRandomNumber:number;

myRandomNumber = 'wrong type';