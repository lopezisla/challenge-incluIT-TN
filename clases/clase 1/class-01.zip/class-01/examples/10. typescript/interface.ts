// If you provide an object that doesn’t match the interface you have provided
interface Student {
  name: string;
  lastname: string;
  score: number;
}

const student: Student = {
  name: "Lucas",
  lastname: "Oviedo",
  score: 0,
};